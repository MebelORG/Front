<?php include 'cms-header.php'; ?>

  <div class="cms">

		<div class="cms-container">

      <?php include 'cms-menu.php'; ?>

			<div class="cms-content">

				<div class="cms-promo">

					<h2>Промо коды</h2>

					<div class="cms-action">
						<button class="cms-btn" data-toggle="modal" data-target="#add-product">
						Добавить Промо код
						</button>
					</div>

					<div class="cms-promo__content">

						<div class="cms-promo__item">
							<div class="cms-promo__item-discount">Скидка 12%</div>
							<div class="cms-promo__item-text">При покупке в магазине “Мебельщик”</div>
							<div class="cms-promo__item-date">До 25.06.2017 12:34:34</div>
						</div>

						<div class="cms-promo__item">
							<div class="cms-promo__item-discount">Скидка 12%</div>
							<div class="cms-promo__item-text">При покупке в магазине “Мебельщик”</div>
							<div class="cms-promo__item-date">До 25.06.2017 12:34:34</div>
						</div>

						<div class="cms-promo__item">
							<div class="cms-promo__item-discount">Скидка 12%</div>
							<div class="cms-promo__item-text">При покупке в магазине “Мебельщик”</div>
							<div class="cms-promo__item-date">До 25.06.2017 12:34:34</div>
						</div>

						<div class="cms-promo__item">
							<div class="cms-promo__item-discount">Скидка 12%</div>
							<div class="cms-promo__item-text">При покупке в магазине “Мебельщик”</div>
							<div class="cms-promo__item-date">До 25.06.2017 12:34:34</div>
						</div>

						<div class="cms-promo__item">
							<div class="cms-promo__item-discount">Скидка 12%</div>
							<div class="cms-promo__item-text">При покупке в магазине “Мебельщик”</div>
							<div class="cms-promo__item-date">До 25.06.2017 12:34:34</div>
						</div>

						<div class="cms-promo__item">
							<div class="cms-promo__item-discount">Скидка 12%</div>
							<div class="cms-promo__item-text">При покупке в магазине “Мебельщик”</div>
							<div class="cms-promo__item-date">До 25.06.2017 12:34:34</div>
						</div>

						<div class="cms-promo__item">
							<div class="cms-promo__item-discount">Скидка 12%</div>
							<div class="cms-promo__item-text">При покупке в магазине “Мебельщик”</div>
							<div class="cms-promo__item-date">До 25.06.2017 12:34:34</div>
						</div>

					</div>
					<!-- /cms-promo__content -->

				</div>
				<!-- /cms-promo -->

			</div>
			<!-- /cms-content -->

		</div>
		<!-- /cms-container -->

	</div>
	<!-- /cms -->

<?php include 'cms-footer.php'; ?>
