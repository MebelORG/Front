<?php include 'cms-header.php'; ?>

  <div class="cms">

		<div class="cms-container">

      <?php include 'cms-menu.php'; ?>

			<div class="cms-content">

				<div class="cms-subscribe">

					<div class="cms-sort">
						<div class="cms-sort__item">Все</div>
						<div class="cms-sort__item">Не отвеченые</div>
						<div class="cms-sort__item">Отвеченные</div>
						<div class="cms-sort__item">Отклонённые</div>
						<div class="cms-sort__item">Архив</div>
					</div>
					<!-- /cms-sort -->


					<div class="cms-subscribe__content">
						<div class="cms-subscribe__item">
							<h4>mail@mail.ru</h4>
							<h4>12.12.2008</h4>
							<h4>Подписан / Отписался</h4>
						</div>
						<div class="cms-subscribe__item">
							<h4>mail@mail.ru</h4>
							<h4>12.12.2008</h4>
							<h4>Подписан / Отписался</h4>
						</div>
						<div class="cms-subscribe__item">
							<h4>mail@mail.ru</h4>
							<h4>12.12.2008</h4>
							<h4>Подписан / Отписался</h4>
						</div>
						<div class="cms-subscribe__item">
							<h4>mail@mail.ru</h4>
							<h4>12.12.2008</h4>
							<h4>Подписан / Отписался</h4>
						</div>
						<div class="cms-subscribe__item">
							<h4>mail@mail.ru</h4>
							<h4>12.12.2008</h4>
							<h4>Подписан / Отписался</h4>
						</div>
						<div class="cms-subscribe__item">
							<h4>mail@mail.ru</h4>
							<h4>12.12.2008</h4>
							<h4>Подписан / Отписался</h4>
						</div>
						<div class="cms-subscribe__item">
							<h4>mail@mail.ru</h4>
							<h4>12.12.2008</h4>
							<h4>Подписан / Отписался</h4>
						</div>
					</div>
					<!-- /cms-subscribe__content -->

				</div>
				<!-- /cms-subscribe -->

			</div>
			<!-- /cms-content -->

		</div>
		<!-- /cms-container -->

	</div>
	<!-- /cms -->

<?php include 'cms-footer.php'; ?>
