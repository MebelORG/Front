<!DOCTYPE html>
<html lang="ru">

<head>
 <title>CMS Главная</title>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <meta name="format-detection" content="telephone=no">
 <!-- Favicon -->
 <link rel="icon" href="/ico/favicon.ico" type="image/x-icon">
 <link rel="shortcut icon" href="/ico/favicon.ico" type="image/x-icon">
 <!--Styles-->
 <link rel="stylesheet" href="css/bootstrap.min.css">
 <link rel="stylesheet" href="css/jquery.fancybox.min.css">
 <link rel="stylesheet" href="css/slick-theme.css">
 <link rel="stylesheet" href="css/slick.css">
 <link rel="stylesheet" href="css/main.css">
 <link rel="stylesheet" href="css/media.css">
 <link rel="stylesheet" href="css/dropzone.min.css">
 <link rel="stylesheet" href="css/style.css">
 <link rel="stylesheet" href="css/styles.css">

 <!-- css только для теста -->
 <link rel="stylesheet" href="css/test-only.css">
</head>

<body>
