<?php include 'cms-header.php'; ?>

  <div class="cms">

		<div class="cms-container">

      <?php include 'cms-menu.php'; ?>

			<div class="cms-content">



			</div>
			<!-- /cms-content -->

		</div>
		<!-- /cms-container -->

	</div>
	<!-- /cms -->

<?php include 'cms-footer.php'; ?>
